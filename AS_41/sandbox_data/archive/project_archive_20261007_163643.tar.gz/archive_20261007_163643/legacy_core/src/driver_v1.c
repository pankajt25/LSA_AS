/* Deprecated driver stub */ int init_old() { return 0; }
